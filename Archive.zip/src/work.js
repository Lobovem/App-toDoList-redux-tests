export const validateUserName = function (userName) {
  const isNotBlank = userName !== '';

  // const isNotNumeric = userName

  return isNotBlank;
};
