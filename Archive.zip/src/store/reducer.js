import { act } from '@testing-library/react';

const defaultState = {
  todoListState: JSON.parse(localStorage.getItem('tasks')) || [],
  editTodoState: '',
  inputState: '',
  changeEdit: false,
};

export const todoListReduser = (state = defaultState, action) => {
  switch (action.type) {
    case 'HANDLE_CHECK':
      return {
        ...state,
        todoListState: state.todoListState.map((todo) => (todo.id === action.payload.id ? { ...todo, complete: !todo.complete } : { ...todo })),
      };
    //add task
    case 'ADD_TASK':
      return {
        ...state,
        todoListState: [
          ...state.todoListState,
          {
            //generation random id number
            id: Math.random().toString().substring(2, 5),
            task: action.payload,
            complete: false,
          },
        ],
      };

    case 'SET_CHANGE_EDIT':
      return {
        ...state,
        changeEdit: action.payload,
      };

    //edit task
    // case 'EDIT_TASK':
    //   return {
    //     ...state,
    //   };

    //delete task
    case 'DELETE_TASK':
      return {
        ...state,
        todoListState: state.todoListState.filter((item) => item.id !== action.payload.id),
      };

    //delete all complete task
    case 'DELETE_ALL_COMPLETE_TASK':
      return {
        ...state,
        todoListState: state.todoListState.filter((tasks) => tasks.complete === false),
      };
    case 'EDIT_TODO':
      return {
        ...state,
        editTodoState: action.payload.task,
      };

    case 'REPLACE_TODO':
      // return {
      //   ...state,
      //   todoListState: state.todoListState.map((todo) => (todo.id === action.payload.myTask.id ? { ...todo, task: action.payload.editInput } : { todo })),
      // };
      return {
        ...state,
        todoListState: state.todoListState.map((todo) => {
          if (todo.id === action.payload.myTask.id) {
            todo.task = action.payload.editInput;
          }
          return todo;
        }),
      };

    case 'EDIT_TODO_CHANGE':
      return {
        ...state,
        editTodoState: action.payload,
      };

    case 'INPUT_CHANGE':
      return { ...state, inputState: action.payload };

    default:
      return state;
  }
};
