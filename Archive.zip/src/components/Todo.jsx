import { useState } from 'react';
import s from './style.module.scss';
import { useDispatch, useSelector } from 'react-redux';

export function Todo({ myTask, handleCheck, deleteTask, editTask }) {
  const dispatch = useDispatch();
  const editInput = useSelector((state) => state.todoListReduser.editTodoState);
  const changeEdit = useSelector((state) => state.todoListReduser.changeEdit);

  return (
    <div className={s.todo__wrap}>
      <div
        className={s.todo__btnEdit}
        onClick={() => {
          dispatch({ type: 'EDIT_TODO', payload: myTask });
          dispatch({ type: 'SET_CHANGE_EDIT', payload: !changeEdit });
        }}
      >
        Edit
      </div>

      {changeEdit && (
        <form>
          <button
            onClick={(e) => {
              e.preventDefault();
              dispatch({ type: 'REPLACE_TODO', payload: { myTask, editInput } });
              dispatch({ type: 'SET_CHANGE_EDIT', payload: !changeEdit });
            }}
            className={s.todo__btnApply}
          >
            Apply
          </button>
          <input className={s.todo__taskEdit} type="text" value={editInput} onChange={(e) => dispatch({ type: 'EDIT_TODO_CHANGE', payload: e.target.value })} />
        </form>
      )}

      {!changeEdit && (
        <div className={myTask.complete ? `${s.todo__task} ${s.todo__task_complete}` : s.todo__task}>
          <input
            className={s.todo__checkbox}
            type="checkbox"
            name=""
            id=""
            defaultChecked={myTask.complete}
            onClick={() => dispatch({ type: 'HANDLE_CHECK', payload: myTask })}
          />
          {myTask.task}
        </div>
      )}
      <div className={s.todo__del} onClick={() => dispatch({ type: 'DELETE_TASK', payload: myTask })}>
        X
      </div>
    </div>
  );
}
