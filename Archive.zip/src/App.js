import { useEffect, useState } from 'react';
import { Form } from './components/Form';
import { Todo } from './components/Todo';
import s from './components/style.module.scss';
import { useDispatch, useSelector } from 'react-redux';

function App({ handleChangeEdit, handleSubmitEdit, setTodoEdit, changeForEdit, userInput }) {
  const dispatch = useDispatch();
  const todoList = useSelector((state) => state.todoListReduser.todoListState);

  useEffect(() => {
    localStorage.setItem('tasks', JSON.stringify(todoList));
  }, [todoList]);

  return (
    <div className={s.todo}>
      <h1 className={s.todo__title}>{`Count all tasks - ${todoList.length}`}</h1>
      <Form />

      {todoList.map((myTask) => {
        return (
          <Todo
            key={myTask.id}
            myTask={myTask}
            // userInput={userInput}
            // handleChangeEdit={handleChangeEdit}
            // handleSubmitEdit={handleSubmitEdit}
            // // addTask={addTask}
            // setTodoEdit={setTodoEdit}
            // changeForEdit={changeForEdit}
          />
        );
      })}
    </div>
  );
}

export default App;
